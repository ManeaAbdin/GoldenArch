odoo.define('bi_pos_discount.BiTicketScreen', function(require) {
	'use strict';

	const TicketScreen = require('point_of_sale.TicketScreen');
	const Registries = require('point_of_sale.Registries');
	let check_do = true;

	const BiTicketScreen = (TicketScreen) =>
		class extends TicketScreen {
			setup() {
				super.setup();
			}

			_getToRefundDetail(orderline) {
	            if (orderline.id in this.env.pos.toRefundLines) {
	                return this.env.pos.toRefundLines[orderline.id];
	            } else {
	                const partner = orderline.order.get_partner();
	                const orderPartnerId = partner ? partner.id : false;
	                const newToRefundDetail = {
	                    qty: 0,
	                    orderline: {
	                        id: orderline.id,
	                        productId: orderline.product.id,
	                        price: orderline.price,
	                        qty: orderline.quantity,
	                        refundedQty: orderline.refunded_qty,
	                        orderUid: orderline.order.uid,
	                        orderBackendId: orderline.order.backendId,
	                        orderPartnerId,
	                        tax_ids: orderline.get_taxes().map(tax => tax.id),
	                        discount: orderline.discount,
                        	discount_type: orderline.discount_type,
	                        pack_lot_lines: orderline.pack_lot_lines ? orderline.pack_lot_lines.map(lot => {
	                            return { lot_name: lot.lot_name };
	                        }) : false,
	                    },
	                    destinationOrderUid: false,
	                };
	                this.env.pos.toRefundLines[orderline.id] = newToRefundDetail;
	                return newToRefundDetail;
	            }
	        }

	        _prepareRefundOrderlineOptions(toRefundDetail) {
	            const { qty, orderline } = toRefundDetail;
	            const draftPackLotLines = orderline.pack_lot_lines ? { modifiedPackLotLines: [], newPackLotLines: orderline.pack_lot_lines} : false;
	            return {
	                quantity: -qty,
	                price: orderline.price,
	                extras: { price_automatically_set: true },
	                merge: false,
	                refunded_orderline_id: orderline.id,
	                tax_ids: orderline.tax_ids,
	                discount: orderline.discount,
	                discount_type: orderline.discount_type,
	                draftPackLotLines: draftPackLotLines
	            };
	        }
	};
	Registries.Component.extend(TicketScreen, BiTicketScreen);
	return TicketScreen;
});