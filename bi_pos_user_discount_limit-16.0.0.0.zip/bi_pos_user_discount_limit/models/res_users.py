# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ResUsers(models.Model):
	_inherit = 'res.users'

	fixed_limit = fields.Float(string="Fixed Limit")
	percentage_limit = fields.Float(string="Percentage Limit")

	@api.constrains('percentage_limit')
	def _contrains_percentage_limit(self):
		if self.percentage_limit > 100:
			raise ValidationError(_('Please enter valid percentage limit.\nMaximum percentage limit is 100.'))


class POSSession(models.Model):
	_inherit = 'pos.session'

	def _loader_params_res_users(self):
		result = super()._loader_params_res_users()
		result['search_params']['fields'].append('fixed_limit')
		result['search_params']['fields'].append('percentage_limit')
		return result

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: