# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.
{
    'name': "POS Discount Limit | User Specific Discount Limit",
    'version': '16.0.0.0',
    'category': 'Point of Sale',
    'summary': "Pos discount limitation user discount limit on pos product discount limit fixed discount on point of sales discount limit for user pos discount limit pos discount restriction user wise point of sale discount limit restrict pos discount receipt",
    'description': """ The POS User Discount Limit Odoo app designed to ensures that discounts are managed effectively, preventing misuse and helping businesses maintain profitability at the Point of Sale (POS). POS administrator can configure types of discounts like percentage or fixed and also can define specific discount limits for individual users.""",
    'author': 'BrowseInfo',
    'website': "https://www.browseinfo.com",
    'price': 15,
    'currency': 'EUR',
    'depends': ['base', 'point_of_sale', 'bi_pos_discount'],
    'data': [
        'views/res_users.xml',
    ],
    'assets': {
        'point_of_sale.assets': [
            'bi_pos_user_discount_limit/static/src/js/models.js',
        ],
    },
    'license': 'OPL-1',
    'installable': True,
    'application': False,
    'auto_install': False,
    "live_test_url":'https://youtu.be/FC5QJTkEefA',
	"images":['static/description/POS-User-Discount-Limit.gif'],
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
